#pragma once

typedef int TCheie;
typedef int TValoare;
typedef std::pair <TCheie, TValoare> TElem;
